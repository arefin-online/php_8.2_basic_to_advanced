<?php include_once('header.php'); ?>

<h2 class="mb_10">Registration Success</h2>

<p>Registration is successful.</p>
<p>
    <a href="<?php echo BASE_URL; ?>login.php">Go to Login Page</a>
</p>

<?php include_once('footer.php'); ?>